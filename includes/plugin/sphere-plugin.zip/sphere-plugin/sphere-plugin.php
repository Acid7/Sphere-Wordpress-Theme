<?php
/*
 * Plugin Name:     Sphere Plugin
 * Description:     Core plugin: Sphere — Ajax Portfolio Theme
 * Author:          Acid7
 * Author URI:      acid7.studio
 * Version:         1.0.0
 * Text Domain: 	sphere-plugin
 * Domain Path: 	/languages
 */

if (!defined('ABSPATH')) {
	exit;
}

add_action('plugins_loaded', 'a7x_sphere_plugin_textdomain');
function a7x_sphere_plugin_textdomain() {
	load_plugin_textdomain('sphere-plugin', FALSE, plugin_dir_url(__FILE__) . '/languages/');
}

// *****************************
// * * * * Editor Setup * * * *
// ***************************

// Gutenberg JS

add_action('enqueue_block_editor_assets', 'a7x_editor_script');
function a7x_editor_script() {

	wp_enqueue_script('sphere-gutenberg', plugin_dir_url(__FILE__) . '/js/gutenberg.js', array('wp-dom', 'wp-blocks', 'wp-element', 'wp-compose', 'wp-components', 'wp-editor', 'wp-data', 'wp-rich-text', 'wp-i18n'), null, true);

	$screen = get_current_screen();
	if ($screen->post_type == 'portfolio') {
		wp_enqueue_script('sphere-portfolio', plugin_dir_url(__FILE__) . '/js/portfolio-item.js', array('wp-element', 'wp-compose', 'wp-components', 'wp-editor', 'wp-edit-post', 'wp-data', 'wp-plugins', 'wp-i18n'), null, true);
	}

	if ($screen->post_type == 'page') {
		wp_enqueue_script('sphere-portfolio', plugin_dir_url(__FILE__) . '/js/page-colors.js', array('wp-element', 'wp-compose', 'wp-components', 'wp-edit-post', 'wp-data', 'wp-plugins', 'wp-i18n'), null, true);
	}

	if ($screen->post_type == 'testimonials') {
		wp_enqueue_script('sphere-testimonials', plugin_dir_url(__FILE__) . '/js/testimonials.js', array('wp-element', 'wp-compose', 'wp-components', 'wp-edit-post', 'wp-data', 'wp-plugins', 'wp-i18n'), null, true);
	}
}

// Create Gutenberg Blocks Category

add_filter('block_categories', 'a7x_blocks_category', 10, 2);
function a7x_blocks_category($categories, $post) {
	return array_merge($categories, array(array(
		'slug'  => 'sphere-blocks',
		'title' => esc_html__('Sphere Blocks', 'sphere-plugin'),
	)));
}




// ***********************
// * * * * Blocks * * * *
// *********************

// Portfolio Archive

function a7x_portfolio_archive($atts) {

	$settings = shortcode_atts(array(
		'layout'     => 'portfolio-slideshow',
		'posts'      => '-1',
		'category'   => '',
		'orderby'    => 'date',
		'order'      => 'DESC',
	), $atts);

	if (!empty($settings['category'])) {
		$the_query = new WP_Query(array(
			'post_type'      => 'portfolio',
			'posts_per_page' => $settings['posts'],
			'tax_query'      => array(
				array(
					'taxonomy' => 'portfolio-category',
					'field'    => 'slug',
					'terms'    => $settings['category'],
				)
			),
			'orderby'     => $settings['orderby'],
			'order'       => $settings['order'],
			'post_status' => 'publish',
		));

	} else {
		$the_query = new WP_Query(array(
			'post_type'      => 'portfolio',
			'posts_per_page' => $settings['posts'],
			'orderby'        => $settings['orderby'],
			'order'          => $settings['order'],
			'post_status'    => 'publish',
		));
	}

	ob_start();

	$portfolio_layout = $settings['layout'];

	echo '<div class="'. esc_attr($portfolio_layout) .' portfolio-items">';

		while ($the_query->have_posts()): $the_query->the_post();
			get_template_part('layouts/' . $portfolio_layout);
		endwhile;

	echo '</div>';

	return ob_get_clean();
	wp_reset_postdata();
}

if (function_exists('register_block_type')) {
	register_block_type('a7x/portfolio-archive', array(
		'attributes'       => array(
			'posts'        => array('type' => 'string', 'default' => '-1'),
			'category'     => array('type' => 'string'),
			'layout'       => array('type' => 'string', 'default' => 'portfolio-slideshow'),
			'orderby'      => array('type' => 'string', 'default' => 'date'),
			'order'        => array('type' => 'string', 'default' => 'DESC'),
			'className'    => array('type' => 'string', 'default' => ''),
			'revealFx'	   => array('type' => 'string', 'default' => ''),
			'revealDelay'  => array('type' => 'string', 'default' => ''),
		),
		'render_callback' => 'a7x_portfolio_archive',
	));
}




// *********************************
// * * * * Page Colors Meta * * * *
// *******************************

add_action('init', 'a7x_page_colors_meta');
function a7x_page_colors_meta() {
	register_meta('post', '_a7x_page_bg_color', array(
		'type'           => 'string',
		'single'         => true,
		'show_in_rest'   => true,
		'object_subtype' => 'page',
		'auth_callback'  => function(){
			return current_user_can('edit_posts');
		}
	));

	register_meta('post', '_a7x_page_text_color', array(
		'type'           => 'string',
		'single'         => true,
		'show_in_rest'   => true,
		'object_subtype' => 'page',
		'auth_callback'  => function(){
			return current_user_can('edit_posts');
		}
	));
}




// ************************************
// * * * * Portfolio Post Type * * * *
// **********************************

add_action('init', 'a7x_portfolio_post_type');
function a7x_portfolio_post_type() {

	$labels = array(
		'name'               => esc_html__('Portfolio', 'sphere-plugin'),
		'singular_name'      => esc_html__('Item', 'sphere-plugin'),
		'menu_name'          => esc_html__('Portfolio', 'sphere-plugin'),
		'all_items'          => esc_html__('All Items', 'sphere-plugin'),
		'add_new'            => esc_html__('Add New Item', 'sphere-plugin'),
		'add_new_item'       => esc_html__('Add New Item', 'sphere-plugin'),
		'edit_item'          => esc_html__('Edit Item', 'sphere-plugin'),
		'new_item'           => esc_html__('New Item', 'sphere-plugin'),
		'view_item'          => esc_html__('View Item', 'sphere-plugin'),
		'search_items'       => esc_html__('Search Items', 'sphere-plugin'),
		'not_found'          => esc_html__('No items found', 'sphere-plugin'),
		'not_found_in_trash' => esc_html__('No items found in the Trash', 'sphere-plugin'),
		'parent_item_colon'  => ''
	);

	$args = array(
		'labels'            => $labels,
		'public'            => true,
		'show_in_nav_menus' => false,
		'menu_position'     => 8,
		'supports'          => array('title', 'editor', 'thumbnail', 'custom-fields'),
		'taxonomies'        => array('portfolio-category'),
		'menu_icon'         => 'dashicons-screenoptions',
		'show_in_rest'      => true,
	);

	register_post_type('portfolio', $args);

	register_meta('post', '_a7x_portfolio_item_date', array(
		'type'           => 'string',
		'single'         => true,
		'show_in_rest'   => true,
		'object_subtype' => 'portfolio',
		'auth_callback'  => function(){
			return current_user_can('edit_posts');
		}
	));

	register_meta('post', '_a7x_portfolio_item_client', array(
		'type'           => 'string',
		'single'         => true,
		'show_in_rest'   => true,
		'object_subtype' => 'portfolio',
		'auth_callback'  => function(){
			return current_user_can('edit_posts');
		}
	));

	register_meta('post', '_a7x_portfolio_item_role', array(
		'type'           => 'string',
		'single'         => true,
		'show_in_rest'   => true,
		'object_subtype' => 'portfolio',
		'auth_callback'  => function(){
			return current_user_can('edit_posts');
		}
	));

	register_meta('post', '_a7x_portfolio_item_link', array(
		'type'           => 'string',
		'single'         => true,
		'show_in_rest'   => true,
		'object_subtype' => 'portfolio',
		'auth_callback'  => function(){
			return current_user_can('edit_posts');
		}
	));

	register_meta('post', '_a7x_portfolio_item_bg_color', array(
		'type'           => 'string',
		'single'         => true,
		'show_in_rest'   => true,
		'object_subtype' => 'portfolio',
		'auth_callback'  => function(){
			return current_user_can('edit_posts');
		}
	));

	register_meta('post', '_a7x_portfolio_item_text_color', array(
		'type'           => 'string',
		'single'         => true,
		'show_in_rest'   => true,
		'object_subtype' => 'portfolio',
		'auth_callback'  => function(){
			return current_user_can('edit_posts');
		}
	));

	register_meta('post', '_a7x_portfolio_item_header_image', array(
		'type'           => 'string',
		'single'         => true,
		'show_in_rest'   => true,
		'object_subtype' => 'portfolio',
		'auth_callback'  => function(){
			return current_user_can('edit_posts');
		}
	));

	register_meta('post', '_a7x_portfolio_item_overlay', array(
		'type'           => 'string',
		'single'         => true,
		'show_in_rest'   => true,
		'object_subtype' => 'portfolio',
		'auth_callback'  => function(){
			return current_user_can('edit_posts');
		}
	));

}

// Update Portfolio Messages

add_filter('post_updated_messages', 'a7x_update_portfolio_messages');
function a7x_update_portfolio_messages($messages) {

	global $post, $post_ID;

	$messages['portfolio'] = array(

		0 => '',
		1 => sprintf( esc_html__('Item updated. <a href="%s">View Item</a>', 'sphere-plugin'), esc_url(get_permalink($post_ID)) ),
		2 => esc_html__('Custom field updated.', 'sphere-plugin'),
		3 => esc_html__('Custom field deleted.', 'sphere-plugin'),
		4 => esc_html__('Item updated.', 'sphere-plugin'),

		5 => isset($_GET['revision']) ? sprintf( esc_html__('Item restored to revision from %s', 'sphere-plugin'),
			  wp_post_revision_title((int) $_GET['revision'], false )) : false,

		6 => sprintf( esc_html__('Item published. <a href="%s">View Item</a>', 'sphere-plugin'), esc_url(get_permalink($post_ID)) ),

		7 => esc_html__('Item saved.', 'sphere' ),

		8 => sprintf( esc_html__('Item submitted. <a target="_blank" href="%s">Preview Item</a>', 'sphere-plugin'),
			  esc_url(add_query_arg('preview', 'true', get_permalink($post_ID)) ) ),

		9 => sprintf( esc_html__('Item scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview Item</a>', 'sphere-plugin'),
			  date_i18n( esc_html__('M j, Y @ G:i', 'sphere-plugin'), strtotime($post->post_date)), esc_url(get_permalink($post_ID)) ),

		10 => sprintf( esc_html__('Item draft updated. <a target="_blank" href="%s">Preview Item</a>', 'sphere-plugin'),
				esc_url(add_query_arg('preview', 'true', get_permalink($post_ID)) ) ),

	);

	return $messages;
}

// Portfolio Taxonomy

add_action('init', 'a7x_register_portfolio_categories', 0);
function a7x_register_portfolio_categories() {

	$labels = array(
		'name'              => esc_html__('Portfolio Categories', 'sphere-plugin'),
		'singular_name'     => esc_html__('Portfolio Category', 'sphere-plugin'),
		'search_items'      => esc_html__('Search Portfolio Categories', 'sphere-plugin'),
		'all_items'         => esc_html__('All Portfolio Categories', 'sphere-plugin'),
		'parent_item'       => esc_html__('Parent Portfolio Category', 'sphere-plugin'),
		'parent_item_colon' => esc_html__('Parent Portfolio Category:', 'sphere-plugin'),
		'edit_item'         => esc_html__('Edit Portfolio Category', 'sphere-plugin'),
		'update_item'       => esc_html__('Update Portfolio Category', 'sphere-plugin'),
		'add_new_item'      => esc_html__('Add New Portfolio Category', 'sphere-plugin'),
		'new_item_name'     => esc_html__('New Portfolio Category', 'sphere-plugin'),
		'menu_name'         => esc_html__('Portfolio Categories', 'sphere-plugin'),
	);

	$args = array(
		'labels'            => $labels,
		'hierarchical'      => true,
		'show_admin_column' => true,
		'show_in_nav_menus' => false,
		'show_in_rest'      => true,
	);

	register_taxonomy('portfolio-category', 'portfolio', $args);
}




// ***************************************
// * * * * Testimonials Post Type * * * *
// *************************************

add_action('init', 'a7x_testimonials_post_type');
function a7x_testimonials_post_type() {

	$labels = array(
		'name'               => esc_html__('Testimonials', 'sphere-plugin'),
		'singular_name'      => esc_html__('Item', 'sphere-plugin'),
		'menu_name'          => esc_html__('Testimonials', 'sphere-plugin'),
		'all_items'          => esc_html__('All Items', 'sphere-plugin'),
		'add_new'            => esc_html__('Add New Item', 'sphere-plugin'),
		'add_new_item'       => esc_html__('Add New Item', 'sphere-plugin'),
		'edit_item'          => esc_html__('Edit Item', 'sphere-plugin'),
		'new_item'           => esc_html__('New Item', 'sphere-plugin'),
		'view_item'          => esc_html__('View Item', 'sphere-plugin'),
		'search_items'       => esc_html__('Search Items', 'sphere-plugin'),
		'not_found'          => esc_html__('No items found', 'sphere-plugin'),
		'not_found_in_trash' => esc_html__('No items found in the Trash', 'sphere-plugin'),
		'parent_item_colon'  => ''
	);

	$args = array(
		'labels'            => $labels,
		'public'            => true,
		'show_in_nav_menus' => false,
		'menu_position'     => 9,
		'supports'          => array('title', 'editor', 'thumbnail', 'custom-fields'),
		'menu_icon'         => 'dashicons-editor-quote',
		'show_in_rest'      => true,
	);

	register_post_type('testimonials', $args);

	register_meta('post', '_a7x_testimonials_author', array(
	   'type'           => 'string',
	   'single'         => true,
	   'show_in_rest'   => true,
	   'object_subtype' => 'testimonials',
	   'auth_callback'  => function(){
		   return current_user_can('edit_posts');
	   }
	));

	register_meta('post', '_a7x_testimonials_author_subtitle', array(
	   'type'           => 'string',
	   'single'         => true,
	   'show_in_rest'   => true,
	   'object_subtype' => 'testimonials',
	   'auth_callback'  => function(){
		   return current_user_can('edit_posts');
	   }
	));

}

// Testimonials Slider

function a7x_testimonials_slider($atts) {

	$the_query = new WP_Query(array(
		'post_type'      => 'testimonials',
		'post_status'    => 'publish',
	));

	$id = uniqid();
	ob_start();

	echo '<div class="testimonials-slider">';

		while ($the_query->have_posts()): $the_query->the_post();
			get_template_part('layouts/testimonials');
		endwhile;

	echo '</div>';

	return ob_get_clean();
	wp_reset_postdata();
}

if (function_exists('register_block_type')) {
	register_block_type('a7x/testimonials-slider', array(
		'render_callback' => 'a7x_testimonials_slider',
	));
}




// ****************************
// * * * * Share Links * * * *
// **************************

add_action('wp_enqueue_scripts', 'a7x_share_links_js');
function a7x_share_links_js() {
	wp_enqueue_script('sharer', plugin_dir_url( __FILE__ ) . 'lib/sharer.min.js', array(), '0.4.0', true);
}

function a7x_share_links() { ?>

	<div class="share-article">
		<div class="share-wrapper">

			<h5 class="share-title"><?php esc_html_e('Share', 'sphere-plugin'); ?></h5>
			<div class="share-links">
				<a href="mailto:?subject=<?php echo esc_html(rawurlencode(get_the_title())); ?>&body=<?php echo esc_url(get_permalink()); ?>"><?php esc_html_e('Email.', 'sphere-plugin'); ?></a>
				<a href="#" data-sharer="twitter" data-title="<?php the_title(); ?>" data-url="<?php echo esc_url(get_permalink()); ?>"><?php esc_html_e('Twitter.', 'sphere-plugin'); ?></a>
				<a href="#" data-sharer="facebook" data-url="<?php echo esc_url(get_permalink()); ?>"><?php esc_html_e('Facebook.', 'sphere-plugin'); ?></a>
				<a href="#" data-sharer="pinterest" data-url="<?php echo esc_url(get_permalink()); ?>" data-image="<?php echo esc_url(get_the_post_thumbnail_url()); ?>"><?php esc_html_e('Pinterest.', 'sphere-plugin'); ?></a>
			</div>

		</div>
	</div>

<?php }
